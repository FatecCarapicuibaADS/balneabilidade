function pagecontainershow_main(e,ui){
	//colocar código específico para cada página.
	//document.addEventListener("deviceready", onDeviceReady, false);
}

function calcular(){
	//ler dados dos inputs
	var txtAltura = $('#txtAltura').val();
	var txtPeso = $('#txtPeso').val();
	//calcular a formula do IMC
	var altura = parseFloat(txtAltura);
	var peso = parseFloat(txtPeso);
	var imc = peso/(altura*altura);	   
	//salvar no sessionstorage
	sessionStorage.setItem("imc", imc.toString() );
   //navegar para a próxima página
	$.mobile.pageContainer.pagecontainer("change", "resultado.html");

}
//http://meumobi.github.io/stocks%20apis/2016/03/13/get-realtime-stock-quotes-yahoo-finance-api.html
